#!/usr/bin/env python

def simple_module_function():
  print("This is the code from the module")